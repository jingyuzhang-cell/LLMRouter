# STAGE_D 终局执行器最终审计（第四阶段，零调用）

**日期**：2026-11-02  
**结论**：192 块零调用 Dry-run 全部通过；终局执行器可执行 V1.3.2 的 S0–S5 矩阵。**但尚不能冻结为“可执行 GO”的状态**——存在 6 项 BLOCKED（其中 3 项需操作员裁定），且预注册包当前存在 26 vs 19 的清单冲突。  
**真实模型调用**：0；**API 费用**：0；**192 真实执行**：未授权、未启动。

---

## 一、交付物

| # | 文件 | 作用 |
|---|---|---|
| 1 | `STAGE_D_EXECUTOR_ASSET_AUDIT.md` | 第一阶段代码资产审计 |
| 2 | `stage_d_executor.py` | 终局执行器（S0–S5，192 块） |
| 3 | `stage_d_executor_config.json` | 执行矩阵/预算/槽位/S5/截止配置 |
| 4 | `test_stage_d_executor.py` | 19 个零调用测试（18 默认 + 1 完整 192） |
| 5 | `STAGE_D_DRYRUN_FULL.log` | 完整 192 dry-run 日志 |
| 6 | `STAGE_D_EXECUTOR_TEST_COVERAGE.md` | 20 项检查映射与结果 |
| 7 | `STAGE_D_EXECUTOR_MATRIX.json` | 192 矩阵核验 |
| 8 | `STAGE_D_EXECUTOR_TOKEN_CAP.md` | token 上界核算（建议 9.5M，精确计量 BLOCKED） |
| 9 | `STAGE_D_EXECUTOR_SHA256.json` | 执行器产物 SHA-256 清单 |
| 10 | 本文件 | 最终审计（PASS/FAIL/BLOCKED） |

## 二、复用了什么 / 为什么必须改

| 模块 | 处置 | 理由 |
|---|---|---|
| `d2_executor.Exec` 状态机、六臂 `policy`、`detect`、`REPAIR_LIB`、S3/S4 注入 | **复用**（子类继承，D2 源码未改） | 六臂策略/修复已在 D2 108 执行中验证；不重写 |
| `stage_a/executor.py` 提示词/合同/终端构建/格式规则 | **复用**（只读） | 冻结合同与终端评分边界 |
| `terminal_quality.evaluate_terminal_quality` | **复用**（只读） | P0 评分器；执行器只消费 |
| `transport.call_model` | 经 `RealProvider` 包装；dry-run 不使用 | 真实调用默认禁用 |
| D2 `time.time()` 的 policy/detect/action | **重写为虚拟时钟版** | D2 与虚拟时钟混用会误判剩余时间 |
| 全局预算/槽位/断点/token/原始-评分分层/S5/分析输入 | **新增** | D2 只有每执行局部预算与文件级跳过 |

**未修改**：V1.3.2、`exact_perm.py`、`power_sim.py`、`stage_d_final_analysis.py`、`d2_executor.py`、`runs_d2/` 历史结果。

## 三、测试与 dry-run 证据

- 默认测试套件：**19 tests, OK (skipped=1)**；完整 192 用例单独运行 **1 test OK（4.55s）**。
- 完整 CLI dry-run：**192 记录 / 192 唯一 ID / 全部 COMPLETE**；六臂各 32；S0–S5 = 12/18/18/48/48/48（即每臂 2/3/3/8/8/8）。
- S5 竞速：π-only / Fixed-Composite / Proposed-Dynamic 各 8 次触发；Static / R-only / Simple 0 次；DS 全部胜出；取消有效/迟到两种模式均通过。
- 成本：1,451 调用；核算 ¥2.358712；实际现金代理 ¥0.080276；远低于全局硬顶 2,688 / ¥34.56。
- 双槽：最大并发 glm=2 / ds=1，无超额。
- 恢复：二次 CLI 运行 `skipped=1`；全局 calls == 记录 calls 之和，无重复计账。
- 配对一致性：S3/S4/S5 每个 `(scenario, rep)` 的 E1 基础输出在六臂间逐字相同（192 记录比对，0 差异），策略差异仅来自 action/repair。

## 四、PASS / FAIL / BLOCKED

### PASS（有实际测试证据）

192 矩阵；六臂/场景计数；S5 GLM 先行+SLO 9.5s 触发+DS 竞速+首个可解析胜出；取消有效与迟到响应；迟到成本入账；双槽不超额；每执行/全局调用与现金硬停；截止硬停；token 硬停；断点恢复；已完成不重跑；成本不重复；异常记录；原始/评分分离；结果进入 `stage_d_final_analysis.py`；完整 192 dry-run；Mock 零网络。

### FAIL

无（本轮测试未发现失败项）。

### BLOCKED（不得写成 PASS）

| # | 项 | 原因 | 影响 |
|---|---|---|---|
| B1 | 真实网络取消/限流/并发性能 | Mock 只验证控制流；`RealProvider` 是同步 `urllib`，不能干净取消 | 真实执行的取消/迟到语义需在 GO 后实测；不得用 dry-run 宣称网络性能 |
| B2 | S5 绝对时延/按时率 | Mock 时钟含线程调度噪声：48 个 S5 记录全部 `on_time=false`（~105–130s）；89.9s 是预注册压力测试预测，不是实测 | S5 时延结论只能由真实 192 执行产生；dry-run 不作时延证据 |
| B3 | 精确 token 计量 | 无真实 tokenizer；当前用字符代理（建议上限 9.5M） | GO 的 token 上限是保守上界，不是精确 tokenizer 结果 |
| B4 | 保护集真实计数 | 终局分析入口消费 `protection_regressions`；执行器只记录 claim/slot 数据，8 槽×384 槽-run 的口径未由操作员最终确认 | 当前 `FINAL_RUNS.json` 用 `protection_regressions=0`（MOCK）标注；真实计数需另行审计 |
| B5 | S5 截止期 90s vs 任务书 180s | V1.1/V1.2 冻结 S5 为紧截止变体 D=90s；任务书统一写 180s | 执行器按预注册实现 S5=90s，其余 180s；需操作员确认，否则 S5 按时率效应改变 |
| B6 | 预注册包数量冲突 | 当前 `MANIFEST_STAGE_D.json` = **26 项**（26/26 自洽，V1.3.2=`f258b5e0…`），但 V1.3.2 §六 仍写 **19 项**；V1.3.2 在 10:42 被并行进程修改 | 预注册包尚不能称“最终冻结”；执行器包与预注册包保持分离，未写入该清单 |

## 五、关键限制与诚实声明

- 完整 dry-run 的 `stage_d_final_analysis.py` 输出 p=0.0039 是 **Mock 数据产物**（S4 Simple TP=0、Proposed 修复后 TP=2），**不是科学证据**；不得引用为确认性结果。
- Mock 的 S5 makespan（~105–130s）不是预注册 89.9s 的复现，也不构成对其的否定；真实时延需真实执行。
- 执行器代码在本轮结束后应冻结哈希；在此之前不得启动真实执行。
- 真实调用授权仍只能由操作员以明文 GO（批次名/调用上限/token 上限/现金上限）签发；本报告不构成授权。

## 六、下一步（零调用优先）

1. 操作员裁定 B5（S5 截止 90 或 180）与 B4（保护集计数口径）。
2. 确认 B3 的 token 上限（建议 9.5M）并写入配置；或提供本地 tokenizer 做零调用精确校准。
3. 解决 B6 的 26 vs 19 清单冲突（预注册包层面）。
4. 冻结 `stage_d_executor.py` + 配置 + 测试的 SHA-256。
5. 以上完成后，另提交 GO 申请；在此之前不启动 192 真实执行。
